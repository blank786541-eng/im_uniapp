const c={appKey:"cd693c66bb6992a7cc2b13379e981d48"};export{c};
