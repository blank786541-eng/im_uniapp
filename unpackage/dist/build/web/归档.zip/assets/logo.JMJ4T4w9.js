const o=""+new URL("logo-Dc1ki8wi.png",import.meta.url).href;export{o as _};
